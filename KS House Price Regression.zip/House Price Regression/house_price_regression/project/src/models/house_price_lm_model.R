library(ggplot2)
library(lattice)
library(caret) #http://topepo.github.io/caret/index.html
library(data.table)
library(Metrics)

set.seed(77)

houseData<-fread('./project/volume/data/interim/Stat_380_housedata.csv')

houseDatanA <- houseData[is.na(SalePrice)]

train <- houseData[, TotRoomsAbvgrd := as.factor(TotRmsAbvGrd)]
train <- houseData[, yearBuilt := as.factor(YearBuilt)]
train <- houseData[, bedroomAbvgr := as.factor(BedroomAbvGr)]
train <- houseData[, yearSold := as.factor(YrSold)]

test <- houseDatanA[, TotRoomsAbvgrd := as.factor(TotRmsAbvGrd)]
test <- houseDatanA[, yearBuilt := as.factor(YearBuilt)]
test <- houseDatanA[, bedroomAbvgr := as.factor(BedroomAbvGr)]
test <- houseDatanA[, yearSold := as.factor(YrSold)]

#Fit the linear model
fit<-lm(SalePrice ~ LotArea + TotRmsAbvGrd + YearBuilt + BedroomAbvGr + GrLivArea + YrSold, data = train)
summary(fit)

train$pred<-predict(fit, newdata = train)


test$pred<-predict(fit, newdata = test)

FinalTest <- test[, SalePrice := 0][, SalePrice := pred][, .(Id, SalePrice)]

finalOrder <- FinalTest[, Order := as.numeric(gsub(pattern = ".*_", replacement = "", x = Id))]

submit <- finalOrder[order(Order)][, c("Id", "SalePrice")]

fwrite(submit,"./project/volume/data/processed/ks_submit_lm.csv")


